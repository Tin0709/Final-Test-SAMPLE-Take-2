import React from "react";

const Home = () => {
  return <h1>Welcome to Full Stack Development</h1>;
};

export default Home;
